package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sellers")
public class SellerController {
    @Autowired
    private SellerService sellerService;

    // Get all sellers
    @GetMapping("/all")
    public List<Seller> getAllSellers() {

        return sellerService.getAllSellers();
    }

    // Get a seller by user ID
    @GetMapping("/{userId}")
    public Seller getSellerByUserId(@PathVariable int userId) {
        return sellerService.getSellerByUserId(userId);
    }

    @GetMapping("/{sellerId}")
    public Seller getSellerBySellerId(@PathVariable int sellerId){
        return sellerService.getSellerBySellerId(sellerId);
    }

    // Create a new seller
    @PostMapping("/new")
    public List<Seller> createSeller(@RequestParam int userId, @RequestBody Seller seller) {
         sellerService.addSeller(userId, seller);
         return sellerService.getAllSellers();
    }

    // Update an existing seller
    @PutMapping("/update/{sellerId}")
    public Seller updateSeller(@PathVariable int sellerId, @RequestBody Seller seller) {
        sellerService.updateSeller(sellerId, seller);
        return sellerService.getSellerBySellerId(sellerId);
    }

    // Delete a seller by ID
    @DeleteMapping("/delete/{sellerId}")
    public List<Seller> deleteSeller(@PathVariable int sellerId) {
        sellerService.deleteSeller(sellerId);
        return sellerService.getAllSellers();
    }
}
