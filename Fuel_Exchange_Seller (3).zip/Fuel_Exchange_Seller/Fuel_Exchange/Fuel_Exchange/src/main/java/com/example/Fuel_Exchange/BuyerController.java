package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/buyer")
public class BuyerController {
    @Autowired
    private BuyerService buyerService;

    @GetMapping("/all")
    public List<com.example.Fuel_Exchange.Buyer> getAllBuyers(){
        return buyerService.getAllBuyers();
    }
    @GetMapping("/{buyerId}")
    public com.example.Fuel_Exchange.Buyer getBuyerById(@PathVariable int buyerId) {
        return buyerService.getBuyerById(buyerId);
    }

    @PostMapping("/new")
    public List<com.example.Fuel_Exchange.Buyer> createBuyer(@RequestParam int userId, @RequestBody com.example.Fuel_Exchange.Buyer buyer) {
        buyerService.addBuyer(userId, buyer);
        return buyerService.getAllBuyers();
    }

    @PutMapping("/update/{id}")
    public com.example.Fuel_Exchange.Buyer updateBuyer(@PathVariable int buyerId, @RequestBody com.example.Fuel_Exchange.Buyer buyer) {
        buyerService.updateBuyer(buyerId, buyer);
        return buyerService.getBuyerById(buyerId);
    }

    @DeleteMapping("/delete/{buyerId}")
    public void deleteBuyer(@PathVariable int buyerId) {
        buyerService.deleteBuyer(buyerId);
    }
}
