package com.example.Fuel_Exchange;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reviews")
public class ReviewController {

    @Autowired
    private ReviewService reviewService;

    @GetMapping
    public List<com.example.Fuel_Exchange.Review> getAllReviews() {
        return reviewService.getAllReviews();
    }

    @GetMapping("/{reviewId}")
    public com.example.Fuel_Exchange.Review getReviewById(@PathVariable Long reviewId) {
        return reviewService.getReviewById(reviewId).orElse(null);
    }

    @PostMapping("/new")
    public com.example.Fuel_Exchange.Review createReview(@RequestBody com.example.Fuel_Exchange.Review review) {
        return reviewService.addReview(review);
    }

    @PutMapping("/{reviewId}")
    public ResponseEntity<com.example.Fuel_Exchange.Review> updateReview(@PathVariable Long reviewId, @RequestBody com.example.Fuel_Exchange.Review reviewDetails) {
        com.example.Fuel_Exchange.Review updatedReview = reviewService.updateReview(reviewId, reviewDetails);
        return updatedReview != null ? ResponseEntity.ok(updatedReview) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{reviewId}")
    public ResponseEntity<Void> deleteReview(@PathVariable Long reviewId) {
        reviewService.deleteReview(reviewId);
        return ResponseEntity.noContent().build();
    }
}
