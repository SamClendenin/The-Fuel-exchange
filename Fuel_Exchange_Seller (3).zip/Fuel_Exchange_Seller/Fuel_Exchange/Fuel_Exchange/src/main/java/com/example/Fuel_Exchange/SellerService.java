package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SellerService {
    @Autowired
    private SellerRepository sellerRepository;

    @Autowired
    private UserRepository userRepository;

    // Get all sellers
    public List<Seller> getAllSellers() {

        return sellerRepository.findAll();
    }

    // Get a seller by userId
    public Seller getSellerByUserId(int userId) {
        return sellerRepository.findById(userId).orElse(null);
    }

    public Seller getSellerBySellerId(int sellerId){

        return sellerRepository.findById(sellerId).orElse(null);
    }

    public void deleteUser(int userId){
        Seller seller = sellerRepository.findByUser_userId(userId);
        if (seller != null){
            sellerRepository.delete(seller);
        }
        userRepository.deleteById(userId);
    }

    // Add a new seller
    public void addSeller(int userId, Seller seller) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        seller.setUser(user);
        sellerRepository.save(seller);
    }

    // Update a seller's information
    public void updateSeller(int sellerId, Seller seller) {
        Seller existingSeller = sellerRepository.findById(sellerId).orElse(null);
        if (existingSeller != null) {
            existingSeller.setBusinessName(seller.getBusinessName());
            existingSeller.setBusinessInfo(seller.getBusinessInfo());
            existingSeller.setFuelTypes(seller.getFuelTypes());
            sellerRepository.save(existingSeller);
        }
    }

    // Delete a seller by ID
    public void deleteSeller(int sellerId) {
        sellerRepository.deleteById(sellerId);
    }
}
