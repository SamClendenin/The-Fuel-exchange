package com.example.Fuel_Exchange;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/all")
    public List<com.example.Fuel_Exchange.Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    @GetMapping("/{orderId}")
    public com.example.Fuel_Exchange.Order getOrderById(@PathVariable int orderId){
        return orderService.getOrderById(orderId).orElse(null);
    }

    @PostMapping("/new")
    public com.example.Fuel_Exchange.Order createOrder (@RequestBody com.example.Fuel_Exchange.Order order) {
        return orderService.addOrder(order);
    }

    @PutMapping("/{orderId}")
    public ResponseEntity<com.example.Fuel_Exchange.Order> updateOrder(@PathVariable int orderId, @RequestBody com.example.Fuel_Exchange.Order orderDetails) {
        com.example.Fuel_Exchange.Order updatedOrder = orderService.updateOrder(orderId, orderDetails);
        return updatedOrder != null ? ResponseEntity.ok(updatedOrder) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{orderId}")
    public ResponseEntity<Void> deleteOrder(@PathVariable int orderId) {
        orderService.deleteOrder(orderId);
        return ResponseEntity.noContent().build();
    }

}
