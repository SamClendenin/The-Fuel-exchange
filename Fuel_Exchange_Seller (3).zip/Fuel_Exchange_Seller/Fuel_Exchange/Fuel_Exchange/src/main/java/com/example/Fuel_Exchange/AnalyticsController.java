package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/analytics")
public class AnalyticsController {
    @Autowired
    private AnalyticsService analyticsService;

    // Get all analytics
    @GetMapping("/all")
    public List<Analytics> getAllAnalytics() {
        return analyticsService.getAllAnalytics();
    }

    // Get analytics by seller ID
    @GetMapping("/{sellerId}")
    public Analytics getAnalyticsBySellerId(@PathVariable int sellerId) {
        return analyticsService.getAnalyticsBySellerId(sellerId);
    }

    // Create new analytics
    @PostMapping("/new")
    public List<Analytics> createAnalytics(@RequestBody Analytics analytics) {
        analyticsService.createAnalytics(analytics);
        return analyticsService.getAllAnalytics();
    }

    // Update existing analytics
    @PutMapping("/update/{analyticsId}")
    public List<Analytics> updateAnalytics(@PathVariable int analyticsId, @RequestBody Analytics updatedAnalytics) {
        analyticsService.updateAnalytics(analyticsId, updatedAnalytics);
        return analyticsService.getAllAnalytics();
    }

    // Delete analytics
    @DeleteMapping("/delete/{analyticsId}")
    public void deleteAnalytics(@PathVariable int analyticsId) {
        analyticsService.deleteAnalytics(analyticsId);
    }
}
