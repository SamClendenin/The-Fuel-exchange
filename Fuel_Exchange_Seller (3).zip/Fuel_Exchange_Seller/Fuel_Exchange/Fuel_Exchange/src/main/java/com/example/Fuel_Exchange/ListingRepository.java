package com.example.Fuel_Exchange;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ListingRepository extends JpaRepository<Listing, Integer> {
    Listing findBySeller_SellerId(int sellerId);
    Listing findBySeller_UserUserId(int sellerUserId);
    Listing findByFuelType(String fuelType);
}
