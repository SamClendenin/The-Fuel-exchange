package com.example.Fuel_Exchange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuelExchangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuelExchangeApplication.class, args);
	}

}
