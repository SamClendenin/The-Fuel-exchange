package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService {

    @Autowired
    private com.example.Fuel_Exchange.MessageRepository messageRepository;

    public List<com.example.Fuel_Exchange.Message> getAllMessages(){
        return messageRepository.findAll();
    }

    public com.example.Fuel_Exchange.Message getMessageById(int messageId){
        return messageRepository.findById(messageId).orElse(null);
    }

    public com.example.Fuel_Exchange.Message addMessage(com.example.Fuel_Exchange.Message message){
        return messageRepository.save(message);
    }

    public com.example.Fuel_Exchange.Message updateMessage(int messageId, com.example.Fuel_Exchange.Message messageDetails) {
        return messageRepository.findById(messageId)
                .map(message -> {
                    message.setSender(messageDetails.getSender());
                    message.setReceiver(messageDetails.getReceiver());
                    message.setMessage(messageDetails.getMessage());
                    message.setTimestamp(messageDetails.getTimestamp());
                    return messageRepository.save(message);
                }).orElse(null);
    }

    public void deleteMessage(int messageId){
        messageRepository.deleteById(messageId);
    }
}
