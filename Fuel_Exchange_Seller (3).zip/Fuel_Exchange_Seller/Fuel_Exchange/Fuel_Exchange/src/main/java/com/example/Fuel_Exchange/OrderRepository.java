package com.example.Fuel_Exchange;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<com.example.Fuel_Exchange.Order, Integer> {

}
