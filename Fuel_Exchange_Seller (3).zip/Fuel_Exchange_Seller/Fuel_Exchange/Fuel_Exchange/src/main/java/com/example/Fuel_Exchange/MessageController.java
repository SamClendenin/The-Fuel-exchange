package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/messages")

public class MessageController {

    @Autowired
    private MessageService messageService;

    @GetMapping
    public List<com.example.Fuel_Exchange.Message> getAllMessages() {
        return messageService.getAllMessages();
    }

    @GetMapping("/{messageId}")
    public com.example.Fuel_Exchange.Message getMessageById(@PathVariable int messageId) {
        return messageService.getMessageById(messageId);
    }

    @PostMapping("/{new}")
    public com.example.Fuel_Exchange.Message createMessage(@RequestBody com.example.Fuel_Exchange.Message message) {
        return messageService.addMessage(message);
    }

    @PutMapping("/{messageId}")
    public ResponseEntity<com.example.Fuel_Exchange.Message> updateMessage(@PathVariable int messageId, @RequestBody com.example.Fuel_Exchange.Message messageDetails) {
        com.example.Fuel_Exchange.Message updatedMessage = messageService.updateMessage(messageId, messageDetails);
        if (updatedMessage != null) {
            return ResponseEntity.ok(updatedMessage);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{messageId}")
    public ResponseEntity<Void> deleteMessage(@PathVariable int messageId) {
        messageService.deleteMessage(messageId);
        return ResponseEntity.noContent().build();
    }

}
