package com.example.Fuel_Exchange;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface SellerRepository extends JpaRepository<Seller, Integer> {

    Seller findBySellerId(int sellerId);
    Seller findByUser_userId(int userId);


    @Modifying
    @Transactional
    @Query("DELETE FROM Seller s WHERE s.user.userId = :userId")
    void deleteByUserId(int userId);

    Seller findByBusinessNameContaining(String businessName);
}
