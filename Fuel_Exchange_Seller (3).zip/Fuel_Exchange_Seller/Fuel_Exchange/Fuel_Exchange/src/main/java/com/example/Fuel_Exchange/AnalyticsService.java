package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnalyticsService {
    @Autowired
    private AnalyticsRepository analyticsRepository;

    public List<Analytics> getAllAnalytics() {
        return analyticsRepository.findAll();
    }

    public Analytics getAnalyticsBySellerId(int sellerId) {
        return analyticsRepository.findById(sellerId).orElse(null);
    }

    public void createAnalytics(Analytics analytics) {
        analyticsRepository.save(analytics);
    }

    public void updateAnalytics(int analyticsId, Analytics updatedAnalytics) {
        Analytics existingAnalytics = analyticsRepository.findById(analyticsId).orElse(null);
        if (existingAnalytics != null) {
            existingAnalytics.setTotalSales(updatedAnalytics.getTotalSales());
            existingAnalytics.setTotalOrders(updatedAnalytics.getTotalOrders());
            existingAnalytics.setTotalRevenue(updatedAnalytics.getTotalRevenue());
            existingAnalytics.setUpdatedAt(updatedAnalytics.getUpdatedAt());
            analyticsRepository.save(existingAnalytics);
        }
    }

    public void deleteAnalytics(int analyticsId) {
        analyticsRepository.deleteById(analyticsId);
    }
}
