package com.example.Fuel_Exchange;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AnalyticsRepository extends JpaRepository<Analytics, Integer> {
    Analytics findBySeller_SellerId(int sellerId);
}
