package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class ReviewService {

    @Autowired
    private com.example.Fuel_Exchange.ReviewRepository reviewRepository;

    public List<com.example.Fuel_Exchange.Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    public Optional<com.example.Fuel_Exchange.Review> getReviewById(Long reviewId) {
        return reviewRepository.findById(reviewId);
    }

    public com.example.Fuel_Exchange.Review addReview(com.example.Fuel_Exchange.Review review) {
        return reviewRepository.save(review);
    }

    public com.example.Fuel_Exchange.Review updateReview(Long reviewId, com.example.Fuel_Exchange.Review reviewDetails) {
        return reviewRepository.findById(reviewId).map(review -> {
            review.setRating(reviewDetails.getRating());
            review.setReviewText(reviewDetails.getReviewText());
            review.setCreatedAt(reviewDetails.getCreatedAt());
            return reviewRepository.save(review);
        }).orElse(null);
    }

    public void deleteReview(Long reviewId) {
        reviewRepository.deleteById(reviewId);
    }
}
