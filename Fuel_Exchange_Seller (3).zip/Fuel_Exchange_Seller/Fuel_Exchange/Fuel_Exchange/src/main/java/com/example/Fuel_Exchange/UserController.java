package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/all")
    public List<User> getAllUsers(){
        return userService.getAllUsers();
    }

    @GetMapping("/{userId}")
    public User getUserById(@PathVariable int userId) {
        return userService.getUserById(userId);
    }

    @PostMapping("/new")
    public List<User> createUser(@RequestBody User user) {
         userService.addUser(user);
         return userService.getAllUsers();
    }

    @PutMapping("/update/{userId}")
    public User updateUser(@PathVariable int userId, @RequestBody User user) {
        userService.updateUser(userId, user);
        return userService.getUserById(userId);
    }

    @DeleteMapping("/delete/{userId}")
    public List<User> deleteUser(@PathVariable int userId) {
        userService.deleteUser(userId);
        return userService.getAllUsers();
    }
}
