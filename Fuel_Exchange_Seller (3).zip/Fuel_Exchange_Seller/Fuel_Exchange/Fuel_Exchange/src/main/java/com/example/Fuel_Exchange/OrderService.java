package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private com.example.Fuel_Exchange.OrderRepository orderRepository;

    public List<com.example.Fuel_Exchange.Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Optional<com.example.Fuel_Exchange.Order> getOrderById(int orderId) {
        return orderRepository.findById(orderId);
    }

    public com.example.Fuel_Exchange.Order addOrder(com.example.Fuel_Exchange.Order order) {
        return orderRepository.save(order);
    }

    public com.example.Fuel_Exchange.Order updateOrder(int orderId, com.example.Fuel_Exchange.Order orderDetails) {
        return orderRepository.findById(orderId).map(order -> {
            order.setBuyer(orderDetails.getBuyer());
            order.setListing(orderDetails.getListing());
            order.setQuantity(orderDetails.getQuantity());
            order.setTotalPrice(orderDetails.getTotalPrice());
            order.setStatus(orderDetails.getStatus());
            order.setCreatedAt(orderDetails.getCreatedAt());
            return orderRepository.save(order);
        }).orElse(null);
    }

    public void deleteOrder(int orderId) {
        orderRepository.deleteById(orderId);
    }
}
