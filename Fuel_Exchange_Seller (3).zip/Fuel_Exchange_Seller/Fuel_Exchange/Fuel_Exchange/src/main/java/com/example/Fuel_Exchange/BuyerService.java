package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BuyerService {

    @Autowired
    private com.example.Fuel_Exchange.BuyerRepository buyerRepository;

    @Autowired
    private UserRepository userRepository;

    public List<com.example.Fuel_Exchange.Buyer> getAllBuyers(){

        return buyerRepository.findAll();
    }


    public com.example.Fuel_Exchange.Buyer getBuyerById(int buyerId){
        return buyerRepository.findById(buyerId).orElse(null);
    }

//    public void addBuyer(com.example.Fuel_Exchange.Buyer buyer){
//        buyerRepository.save(buyer);
//    }

    public void addBuyer(int userId, Buyer buyer) {
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        buyer.setUser(user);
        buyerRepository.save(buyer);
    }

    public void updateBuyer(int buyerId, com.example.Fuel_Exchange.Buyer buyerDetails) {
        com.example.Fuel_Exchange.Buyer existingBuyer = getBuyerById(buyerId);
        if (existingBuyer != null) {
            existingBuyer.setUser(buyerDetails.getUser());
            existingBuyer.setDeliveryAddress(buyerDetails.getDeliveryAddress());
            buyerRepository.save(existingBuyer);
        }
    }

    public void deleteBuyer(int id) {
        buyerRepository.deleteById(id);
    }
}
