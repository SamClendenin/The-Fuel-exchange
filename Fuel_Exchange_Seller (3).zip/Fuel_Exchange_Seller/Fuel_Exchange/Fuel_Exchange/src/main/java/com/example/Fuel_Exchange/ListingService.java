package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ListingService {
    @Autowired
    private ListingRepository listingRepository;

    // Get all listings
    public List<Listing> getAllListings() {
        return listingRepository.findAll();
    }

    // Get listings by seller's userId
    public Listing getListingsBySellerUserId(int sellerUserId) {
        return listingRepository.findById(sellerUserId).orElse(null);
    }

    // Create a new listing
    public void addListing(Listing listing) {
        listingRepository.save(listing);
    }

    // Update an existing listing
    public void updateListing(int listingId, Listing listing) {
        Listing existingListing = listingRepository.findById(listingId).orElse(null);
        if (existingListing != null) {
            existingListing.setTitle(listing.getTitle());
            existingListing.setDescription(listing.getDescription());
            existingListing.setFuelType(listing.getFuelType());
            existingListing.setPrice(listing.getPrice());
            existingListing.setQuantity(listing.getQuantity());
            listingRepository.save(existingListing);
        }
    }

    // Delete a listing
    public void deleteListing(int listingId) {
        listingRepository.deleteById(listingId);
    }

    // Get a specific listing by its ID
    public Listing getListingById(int listingId) {
        return listingRepository.findById(listingId).orElse(null);
    }
}
