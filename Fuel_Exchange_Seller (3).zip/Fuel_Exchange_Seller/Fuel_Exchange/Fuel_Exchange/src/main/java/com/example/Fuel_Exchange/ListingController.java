package com.example.Fuel_Exchange;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;


    @RestController
    @RequestMapping("/listings")
    public class ListingController {

        @Autowired
        private ListingService listingService;

        // Get all listings
        @GetMapping("/all")
        public List<Listing> getAllListings() {
            return listingService.getAllListings();
        }

        // Get listings by seller's userId
        @GetMapping("/seller/{userId}")
        public Listing getListingsBySellerUserId(@PathVariable int userId) {
            return listingService.getListingsBySellerUserId(userId);
        }

        // Get a specific listing by its ID
        @GetMapping("/{listingId}")
        public Listing getListingById(@PathVariable int listingId) {
            return listingService.getListingById(listingId);
        }

        // Create a new listing
        @PostMapping("/new")
        public List<Listing> createListing(@RequestBody Listing listing) {
            listingService.addListing(listing);
            return listingService.getAllListings();
        }

        // Update an existing listing
        @PutMapping("/update/{listingId}")
        public Listing updateListing(@PathVariable int listingId, @RequestBody Listing listing) {
            listingService.updateListing(listingId, listing);
            return listingService.getListingById(listingId);
        }

        // Delete a listing
        @DeleteMapping("/delete/{listingId}")
        public List<Listing> deleteListing(@PathVariable int listingId) {
            listingService.deleteListing(listingId);
            return listingService.getAllListings();
        }
    }