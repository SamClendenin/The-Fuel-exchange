package com.example.Fuel_Exchange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
